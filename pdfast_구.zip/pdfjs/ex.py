import requests
r = requests.get('http://52.79.212.80:56458/')
print (r.text)
